<!DOCTYPE html>
<html>
<head>
    <title>User List</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>User List</h2>
    
    <!-- Search Form -->
    <form method="get" action="<?php echo site_url('/users-list'); ?>" class="mb-3">
        <div class="form-row align-items-center">
            <div class="col-auto">
                <input type="text" name="search" class="form-control mb-2" placeholder="Search" value="<?php echo esc($search); ?>">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary mb-2">Search</button>
            </div>
        </div>
    </form>
    
    <!-- Add User Button -->
    <a href="<?php echo site_url('/user-form') ?>" class="btn btn-primary mb-2">Add User</a>
    
    <!-- Search Link -->
    <a href="<?php echo site_url('/search-user'); ?>" class="btn btn-info mb-2">Search Users</a>
    
    <!-- User Table -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Gender</th>
                <th>Job Title</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if($users): ?>
                <?php foreach($users as $user): ?>
                    <tr>
                        <td><?php echo esc($user['id']); ?></td>
                        <td><?php echo esc($user['first_name']); ?></td>
                        <td><?php echo esc($user['last_name']); ?></td>
                        <td><?php echo esc($user['email']); ?></td>
                        <td><?php echo esc($user['gender']); ?></td>
                        <td><?php echo esc($user['job_title']); ?></td>
                        <td>
                            <a href="<?php echo site_url('edit-view/'.$user['id']); ?>" class="btn btn-info btn-sm">Edit</a>
                            <a href="<?php echo site_url('delete/'.$user['id']); ?>" class="btn btn-danger btn-sm">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center">No users found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
