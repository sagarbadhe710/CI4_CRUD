<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'first_name', 
        'last_name', 
        'email', 
        'gender', 
        'job_title'
    ];

    protected $validationRules = [
        'first_name' => 'required|alpha_space|min_length[3]',
        'last_name'  => 'required|alpha_space|min_length[3]',
        'email'      => 'required|valid_email',
        'gender'     => 'required|in_list[male,female,other]',
        'job_title'  => 'required|alpha_space'
    ];

    protected $validationMessages = [
        'first_name' => [
            'required' => 'First name is required',
            'alpha_space' => 'First name can only contain alphabetical characters and spaces',
            'min_length' => 'First name must be at least 3 characters long'
        ],
        'last_name' => [
            'required' => 'Last name is required',
            'alpha_space' => 'Last name can only contain alphabetical characters and spaces',
            'min_length' => 'Last name must be at least 3 characters long'
        ],
        'email' => [
            'required' => 'Email is required',
            'valid_email' => 'You must provide a valid email address'
        ],
        'gender' => [
            'required' => 'Gender is required',
            'in_list' => 'Gender must be one of: male, female, other'
        ],
        'job_title' => [
            'required' => 'Job title is required',
            'alpha_space' => 'Job title can only contain alphabetical characters and spaces'
        ]
    ];
}
