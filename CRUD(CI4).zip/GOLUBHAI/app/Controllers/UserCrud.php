<?php 
namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class UserCrud extends Controller
{
    public function __construct()
    {
        helper('url', 'form');
    }

    // Users list
    public function index()
    {
        $userModel = new UserModel();
        
        $search = $this->request->getVar('search');
        if ($search) {
            $data['users'] = $userModel->like('first_name', $search)
                                       ->orLike('last_name', $search)
                                       ->orLike('email', $search)
                                       ->orderBy('id', 'DESC')
                                       ->findAll();
            $data['search'] = $search;
        } else {
            $data['users'] = $userModel->orderBy('id', 'DESC')->findAll();
            $data['search'] = '';
        }

        return view('users/index', $data);
    }

    // User form
    public function create()
    {
        return view('users/create');
    }

    // Insert data into database
    public function store()
    {
        $userModel = new UserModel();
        $data = [
            'first_name' => $this->request->getVar('first_name'),
            'last_name'  => $this->request->getVar('last_name'),
            'email'      => $this->request->getVar('email'),
            'gender'     => $this->request->getVar('gender'),
            'job_title'  => $this->request->getVar('job_title'),
        ];
        if ($userModel->insert($data)) {
            return $this->response->redirect(site_url('/users-list'));
        } else {
            $errors = $userModel->errors();
            return view('users/create', ['errors' => $errors]);
        }
    }

    // View single user
    public function singleUser($id = null)
    {
        $userModel = new UserModel();
        $data['user'] = $userModel->find($id);
        return view('users/edit', $data);
    }

    // Update user data
    public function update()
    {
        $userModel = new UserModel();
        $id = $this->request->getVar('id');
        $data = [
            'first_name' => $this->request->getVar('first_name'),
            'last_name'  => $this->request->getVar('last_name'),
            'email'      => $this->request->getVar('email'),
            'gender'     => $this->request->getVar('gender'),
            'job_title'  => $this->request->getVar('job_title'),
        ];
        if ($userModel->update($id, $data)) {
            return $this->response->redirect(site_url('/users-list'));
        } else {
            $errors = $userModel->errors();
            return view('users/edit', ['errors' => $errors, 'user' => $userModel->find($id)]);
        }
    }

    // Delete user
    public function delete($id = null)
    {
        $userModel = new UserModel();
        $userModel->delete($id);
        return $this->response->redirect(site_url('/users-list'));
    }

    // Search page (optional)
    public function search()
    {
        $userModel = new UserModel();
        $search = $this->request->getVar('search');
        if ($search) {
            $data['users'] = $userModel->like('first_name', $search)
                                       ->orLike('last_name', $search)
                                       ->orLike('email', $search)
                                       ->orderBy('id', 'DESC')
                                       ->findAll();
            $data['search'] = $search;
        } else {
            $data['users'] = [];
            $data['search'] = '';
        }
        return view('users/search', $data);
    }
}
